
  /** Background color **/  
  $("#b-cb")
    .keyup(function() {
      var value = $(this).val();
      $(".box").css('background-color',value);
    })
    .keyup();
  
  $("#b-ci").on('keyup', function(e) {
    var ccType = $(this).val();
    if (ccType == "") {
      $(".box").css('background-color', '#E3F2FD');
    }
  })